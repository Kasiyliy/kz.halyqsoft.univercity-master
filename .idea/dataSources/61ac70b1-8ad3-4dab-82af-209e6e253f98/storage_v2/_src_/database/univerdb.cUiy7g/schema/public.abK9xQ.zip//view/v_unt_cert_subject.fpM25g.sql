CREATE VIEW v_unt_cert_subject AS
  SELECT unt_cert.id,
    unt_cert.unt_certificate_id,
    unt_cert.unt_subject_id,
    unt_subj.subject_name AS unt_subject_name,
    unt_cert.rate
   FROM (unt_cert_subject unt_cert
     JOIN unt_subject unt_subj ON ((unt_cert.unt_subject_id = unt_subj.id)));

