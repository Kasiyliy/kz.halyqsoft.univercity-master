CREATE VIEW v_advisor AS
  SELECT empl.id,
    btrim((((((usr.last_name)::text || ' '::text) || (usr.first_name)::text) || ' '::text) || (COALESCE(usr.middle_name, ''::character varying))::text)) AS fio,
    usr.code,
    empl_dept.dept_id,
    dep.dept_name,
    empl_dept.post_id,
    post.post_name
   FROM ((((employee empl
     JOIN users usr ON (((((empl.id = usr.id) AND (empl.employee_status_id = 1)) AND (usr.locked = false)) AND (length((usr.last_name)::text) > 0))))
     JOIN employee_dept empl_dept ON ((((empl.id = empl_dept.employee_id) AND (empl_dept.employee_type_id = 2)) AND (empl_dept.dismiss_date IS NULL))))
     JOIN department dep ON (((empl_dept.dept_id = dep.id) AND (dep.deleted = false))))
     LEFT JOIN post post ON ((empl_dept.post_id = post.id)));

